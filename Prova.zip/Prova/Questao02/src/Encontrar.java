import java.util.Scanner;
import exec.AchadoPerdido;


public class Encontrar {
    public static void main(String[] args) {
        AchadoPerdido AchadoPerdido = new AchadoPerdido("Caneta", "Preta BIC", "Não Possui","Esferográfica", "Portaria", "17/05/2019 14:32", "Localizado");
        Scanner scanner = new Scanner(System.in);
        System.out.print("Insira um texto :");
        String titulo2 = scanner.next();
        AchadoPerdido.buscarTitulo("titulo2");
        AchadoPerdido.visualizaDetalhes();
    }
}
