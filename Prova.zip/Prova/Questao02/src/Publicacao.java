public interface Publicacao {
}
