import Execute.Aluno;
import Execute.Professor;

public class main {
    public static void main(String[] args) {
        Professor Professor = new Professor(200, 5);
        System.out.printf("Os dados do professor sao: " + Professor.mostraProfessor("\nPedro","\npedro.souza@gmail.com \n \n"));

        Execute.Aluno Aluno = new Aluno(1,655);
        System.out.println("Os dados dos alunos sao: " + Aluno.mostraAluno("\nCaio","\ncaiomix@icloud.com","\n1","\n87"));
    }
}
