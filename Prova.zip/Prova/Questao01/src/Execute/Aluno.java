package Execute;

public class Aluno {
    int periodo;
    int turma;

    public Aluno(int periodo, int turma) {
        this.periodo = periodo;
        this.turma = turma;
    }

    public int getPeriodo() {
        return periodo;
    }

    public void setPeriodo(int periodo) {
        this.periodo = periodo;
    }

    public int getTurma() {
        return turma;
    }

    public void setTurma(int turma) {
        this.turma = turma;
    }
    public String mostraAluno(String nome, String email,String periodo, String turma){
        return nome + email + periodo + turma;
    }
}
