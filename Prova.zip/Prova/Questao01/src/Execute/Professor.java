package Execute;

public class Professor {
    float salarioHora;
    int horasAula;
     double salario;

    String nome;

    public Professor(float salarioHora, int horasAula) {
        this.salarioHora = salarioHora;
        this.horasAula = horasAula;
    }

    public float getSalarioHora() {
        return salarioHora;
    }

    public void setSalarioHora(float salarioHora) {
        this.salarioHora = salarioHora;
    }

    public int getHorasAula() {
        return horasAula;
    }

    public void setHorasAula(int horasAula) {
        this.horasAula = horasAula;
    }
    public Double calculaSalario(){
        this.salario = salarioHora * horasAula;
        return salario;
    }
    public String mostraProfessor(String nome, String email){
        return nome + email + calculaSalario();
    }

}
